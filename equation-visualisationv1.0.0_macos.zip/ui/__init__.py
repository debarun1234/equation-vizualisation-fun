"""
UI package for the Mathematical Series Visualization application.
"""

from .main_window import MainWindow

__all__ = ['MainWindow']
