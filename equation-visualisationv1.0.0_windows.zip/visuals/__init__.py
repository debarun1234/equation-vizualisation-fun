"""
Visual components package for mathematical series animations.
"""

# This package will contain specific visualization modules
# Currently integrated into the main UI for simplicity

__all__ = []
